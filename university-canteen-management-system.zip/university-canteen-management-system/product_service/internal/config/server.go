package config

type ServerConfig struct {
	HttpPort           int
	HttpTimeoutSeconds int
}
