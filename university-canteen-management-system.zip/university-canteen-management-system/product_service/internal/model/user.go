package model

type Product struct {
	Uuid     string
	Name    string
	Description string
	Price	int
	Image_url string
	Category_id string
	Total_quantity int
}
